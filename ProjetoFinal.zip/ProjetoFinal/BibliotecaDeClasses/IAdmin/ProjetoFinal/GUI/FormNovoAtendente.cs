﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IAdmin.GUI
{
    public partial class FormNovoAtendente : Form
    {
        public FormNovoAtendente()
        {
            InitializeComponent();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            //lembrar de executar o método para cadastrar o endereço separadamente antes, e dai salvar o atendente

        }
    }
}
