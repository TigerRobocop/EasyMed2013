﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using IMedico.localhostConsulta;

namespace IMedico
{
    public partial class FormGerarParecer : Form
    {        
        Consulta consultaAtual;
        Receita receitaConsulta;
                
        public FormGerarParecer(Consulta c)
        {
            InitializeComponent();
           
            this.consultaAtual = c;

            //load dados do paciente nas labels
            gbDadosPaciente.Text = "Dados do Paciente - Prontuário número: " + consultaAtual.NumeroProntuario.ToString();
            lblNomePaciente.Text = "Nome: " + consultaAtual.Paciente.Nome;
            lblDataNascimento.Text = "Data de nascimento: " + consultaAtual.Paciente.DataNascimento.ToShortDateString();
            lblNomeMae.Text = "Nome da Mãe: " + consultaAtual.Paciente.NomeMae;
            lblNomePai.Text = "Nome do Pai: " + consultaAtual.Paciente.NomePai;
            lblSexo.Text = "Sexo : " + consultaAtual.Paciente.Sexo;

            //load dados do médico nas labels
            lblNomeMedico.Text += " " + c.Medico.Nome;
        }

        private void btFormGerarAtestado_Click(object sender, EventArgs e)
        {
            new FormGerarAtestado().ShowDialog();
        }

        private void btFormGerarReceita_Click(object sender, EventArgs e)
        {
            int codigoMedico = consultaAtual.Medico.Id;
            int codigoPaciente = consultaAtual.Paciente.Id;
            new FormGerarReceita(codigoMedico, codigoPaciente).ShowDialog();

            //btFormGerarReceita.Enabled = false;

            //lblReceitaGerada.Text = "Receita Gerada";
        }

        private void btFinalizarConsulta_Click(object sender, EventArgs e)
        {
            Diagnostico d = new Diagnostico();
            d.Informacoes = txtBoxDiagnostico.Text;
            d.Data = DateTime.Now;

            consultaAtual.Diagnostico = d;

            //registra o diagnostico
            try
            {
                ServiceConsulta svc = new ServiceConsulta();
                consultaAtual.Diagnostico.Id =  svc.registrarDiagnostico(consultaAtual);

                MessageBox.Show("Diagnóstico registrado");           
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }


            //finaliza a consulta
            try
            {
                ServiceConsulta svc2 = new ServiceConsulta();

                svc2.finalizarConsulta(consultaAtual);
                MessageBox.Show("Consulta Finalizada"); 

            }
            catch (Exception ex)
            {
                MessageBox.Show("ERRO: " + ex.Message);
            }

        }
    }
}
